const Restaurant = require('./../models/restaurantModel');
exports.getAllRestaurants = (req,res) => {
};
exports.getRestaurant = (req, res) => {
};
exports.createRestaurant = (req,res) => {
};
exports.updateRestaurant = (req,res) => {
};
exports.deleteRestaurant = (req,res) => {
};